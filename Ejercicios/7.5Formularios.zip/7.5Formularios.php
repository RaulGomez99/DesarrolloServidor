<html>

<head>
  <meta charset="utf-8">
</head>

<body>

  <form action="7.5FormulariosV2.php" method="post">
    Nombre:<input type="text" name="nombre"><br>
    <input type="submit" value="Enviar" name="boton"><br>
  </form>
</body>

</html>